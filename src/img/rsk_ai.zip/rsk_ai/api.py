import rsk
import math
from env import environnement

class api:
    def __init__(self , client):
        self.client = client
        self.poses = self.AllPos()
        self.env = environnement(self)

    def update_poses(self):
        self.poses = self.AllPos()
    
    ####################### GET METHODES #########################

    def AllPos(self):
            try:
                return {'ball':self.client.ball,
                        'green': [None,self.client.robots['green'][1].pose , self.client.robots['green'][2].pose], 
                        'blue': [None,self.client.robots['blue'][1].pose , self.client.robots['blue'][2].pose]
                        }
            except Exception as e:
                print(e + 'get All Robot Pos Error from Api') 

    def Penalised(self):
        try :
            return {
                'green':[None,self.client.referee["teams"]["green"]["robots"]["1"]["penalized"],self.client.referee["teams"]["green"]["robots"]["2"]["penalized"]],
                'blue' : [None,self.client.referee["teams"]["blue"]["robots"]["1"]["penalized"],self.client.referee["teams"]["blue"]["robots"]["2"]["penalized"]]
               }
        except Exception as e:
            print(e + 'get Penalised Error from Api')

    def getPositive(self, color):
        try:
            return self.client.referee["teams"][color]["x_positive"]
        except Exception as e:
            print(e + 'get Side Error from Api')


    ####################### SET METHODES #########################
    def goto(self , robot , x , y , theta):
        try:
            self.client.robots[robot['color']][robot['number']].goto((x , y , theta),wait=False)
        except Exception:
            print('move Error from Api')

    def kick(self , robot , power = 1.0):
        try:
            self.client.robots[robot['color']][robot['number']].kick(power)
        except Exception:
            print('kick Error from Api')

    def control(self,robot,x_speed = 0.0,y_speed = 0.0,theta_speed = 0.0):
        try:
            self.client.robots[robot['color']][robot['number']].control(x_speed,y_speed,theta_speed)
        except Exception:
            print('control Error from Api')

        