from rsk import constants
import math
from api import *
import env

INNACURACY_KICK = 0.14
INNACURACY_AROUND = 0.05
INNACURACY_DISTANCE = 0.02
INNACURACY_BLOCKED = 0.05

class calc:
    def __init__(self, Ienv):
         self.Ienv = Ienv
         self.api = Ienv.api

    def look_at(pos1, pos2):
        return math.atan2(pos2[1] - pos1[1], pos2[0] - pos1[0])
    
    def distance(pos1, pos2):
        return math.sqrt((pos2[0] - pos1[0])**2 + (pos2[1] - pos1[1])**2)
    
    def predictionTire(self,robot):
        pos = self.api.poses[robot['color']][robot['number']]  
        return (constants.defense_area_width*self.Ienv.sign , 
                (constants.defense_area_width*self.Ienv.sign - pos[0])*math.tan(pos[2]) + pos[1])
    
    # def predictionDefenceOLD(self,robot):
    #     pos = self.api.poses[robot['color']][robot['number']]  
    #     sign = -self.Ienv.sign
    #     res = (constants.defense_area_width*sign , 
    #           (constants.defense_area_width*sign - pos[0])*math.tan(pos[2]) + pos[1])
    #     ballpos = self.api.poses['ball']
    #     tetha = pos[2]
        
    #     match(sign):
    #          case 1:
    #              if(not(math.pi/2>=pos[2]>=-math.pi/2)):
    #                 vecteur = (pos[0] - ballpos[0], pos[1] - ballpos[1])
    #                 pente = vecteur[1]/vecteur[0]
    #                 ordonnee_origine = pos[1] - pente*pos[0]
    #                 res = (constants.defense_area_width*sign ,pente * constants.defense_area_width*sign + ordonnee_origine)   
    #          case -1:
    #              if tetha < 0 :
    #                     tetha = 2*math.pi + tetha
    #              if(not(math.pi/2<=tetha<=3*math.pi/2)):
                     
    #                  vecteur = (pos[0] - ballpos[0], pos[1] - ballpos[1])
    #                  pente = vecteur[1]/vecteur[0]
    #                  ordonnee_origine = pos[1] - pente*pos[0]
    #                  res = (constants.defense_area_width*sign ,pente * constants.defense_area_width*sign + ordonnee_origine)   
             
    #     return res
    
    def predictionDefenceVecteur(self,robot):
        pos = self.api.poses[robot['color']][robot['number']]  
        sign = -self.Ienv.sign
        ballpos = self.api.poses['ball']
        vecteur = (pos[0] - ballpos[0], pos[1] - ballpos[1])
        pente = vecteur[1]/vecteur[0]
        ordonnee_origine = pos[1] - pente*pos[0]
        res = (constants.defense_area_width*sign ,pente * constants.defense_area_width*sign + ordonnee_origine)   
         
        return res


    def ballAroundRobot(self, robot,Distance = 0):
        if(self.api.poses[robot['color']][robot['number']].any() == None or self.api.poses['ball'].any() == None):
            return False
        dist = calc.distance(self.api.poses[robot['color']][robot['number']] , self.api.poses['ball'] )
        if(dist < constants.ball_radius + constants.robot_radius + INNACURACY_AROUND + Distance):
            return True
        return False
    
    def isBlocked(self,robot: dict ,zone):
        n=1
        if robot.get('number') == n:
            n=2
        c = 'blue'
        if robot.get('color') == c:
            c = 'green'
        myrobot = self.api.poses[robot['color']][robot['number']]
        r1 = self.api.poses[robot['color']][n]
        r2 = self.api.poses[c][1]
        r3 = self.api.poses[c][2]
        return ((calc.distance(zone, r1) <= constants.robot_radius+INNACURACY_BLOCKED and r1[0]*self.Ienv.sign > myrobot[0]*self.Ienv.sign)
                or (calc.distance(zone, r2) <= constants.robot_radius+INNACURACY_BLOCKED and r2[0]*self.Ienv.sign > myrobot[0]*self.Ienv.sign)
                or (calc.distance(zone, r3) <= constants.robot_radius+INNACURACY_BLOCKED and r3[0]*self.Ienv.sign > myrobot[0]*self.Ienv.sign))

    def canKick(self,robot):
        tetha = self.api.poses[robot['color']][robot['number']][2]
        test1 = self.ballAroundRobot(robot)
        t1 = tetha - INNACURACY_KICK
        t3 = tetha + INNACURACY_KICK
        t1 = calc.toRadiant(t1)
        t3 = calc.toRadiant(t3)

        look = calc.look_at(self.api.poses[robot['color']][robot['number']] , self.api.poses['ball'])
        look = calc.toRadiant(look)
    
        test2 = calc.RadBetween(t1,look,t3)
        mypos = self.api.poses[robot['color']][robot['number']]
        ballpos = self.api.poses['ball']
        
        if( test1 and test2 and mypos[0]*self.Ienv.sign - constants.robot_radius < ballpos[0]*self.Ienv.sign+constants.ball_radius):
            return True
        return False
    
    def canGoal(self,robot):
        tetha = self.api.poses[robot['color']][robot['number']][2]
        tetha = calc.toRadiant(tetha)
        pos = self.api.poses[robot['color']][robot['number']]
        t1 = calc.look_at(pos,(constants.defense_area_width*self.Ienv.sign , -constants.defense_area_length-INNACURACY_AROUND))
        t3 = calc.look_at(pos,(constants.defense_area_width*self.Ienv.sign , constants.defense_area_length+INNACURACY_AROUND))
        t1 = calc.toRadiant(t1)
        t3 = calc.toRadiant(t3)
        return(self.canKick(robot) and calc.RadBetween(t1,tetha,t3) )
            
    
    def enemiesAttaq(self):
        r1 = calc.distance(self.api.poses[env.theirColor][1],self.api.poses['ball'])
        r2 = calc.distance(self.api.poses[env.theirColor][2],self.api.poses['ball'])
        if(r1 < r2):
            return 1
        return 2
    
    def whereToKick(self,robot):
        nbDécoupe = 10
        
        enemie_robot1_position = self.api.poses[env.theirColor][1]
        enemie_robot2_position = self.api.poses[env.theirColor][2]

        myrobot_position = self.api.poses[robot['color']][robot['number']]


        shooting_zones = [(constants.defense_area_width*self.Ienv.sign, y/nbDécoupe) for y in range(int(constants.defense_area_length*nbDécoupe), int(-constants.defense_area_length*nbDécoupe),-1)]

        
        unblocked_zones = [zone for zone in shooting_zones 
                           if not self.isBlocked(robot,zone)]
        
        if(len(unblocked_zones) == 0):
            
            return (constants.defense_area_width*self.Ienv.sign,0)
        best_shooting_zone =  max(unblocked_zones, key=lambda zone: 
                         self.whereToKickNote(zone,enemie_robot1_position,enemie_robot2_position,myrobot_position))

        return best_shooting_zone
    
    def whereToKickNote(self,zone,enemie_robot1_position,enemie_robot2_position,myrobot_position):
        val = -calc.distance(zone, myrobot_position)*1.6
        if (self.Ienv.sign*enemie_robot1_position[0] > self.Ienv.sign*myrobot_position[0]):
            val += (calc.distance(zone, enemie_robot1_position) ) 
        if (self.Ienv.sign*enemie_robot2_position[0] > self.Ienv.sign*myrobot_position[0]):
            val += (calc.distance(zone, enemie_robot2_position) )
        
        val -= (abs(zone[1]))*0.80

        return val
    

    
    def whereToGo(self,robot,add_distance = 0):
        ball = self.api.poses['ball']
        whereToKick = self.whereToKick(robot)
        distance_from_ball = (constants.robot_radius+constants.ball_radius+INNACURACY_DISTANCE+add_distance)*self.Ienv.sign
        vecteur = (whereToKick[0] - ball[0], whereToKick[1] - ball[1])
        norme = math.sqrt(vecteur[0]**2 + vecteur[1]**2)
        coef = distance_from_ball/norme
        pos = (-self.Ienv.sign*vecteur[0]*coef+ball[0], -self.Ienv.sign*vecteur[1]*coef+ball[1])
        return pos
    
    
    
    def toRadiant(angle):
        while(angle > math.pi ):
            angle = angle - 2*math.pi
        while(angle < -math.pi):
            angle = angle + 2*math.pi
        return angle
    
    def RadBetween(t1,t2,t3):
        Res = t1 <= t2 <= t3 or t1 >= t2 >= t3
        if(not(Res)):
            if(t2 > 0):
                if(t1<0):
                    t1 = t1 + 2*math.pi
                if(t3<0):
                    t3 = t3 + 2*math.pi
            else :
                if(t1>0):
                    t1 = t1 - 2*math.pi
                if(t3>0):
                    t3 = t3 - 2*math.pi
            Res = t1 <= t2 <= t3 or t1 >= t2 >= t3
            
        return Res
        
    
    

    
        
    
    
        

    
    
        