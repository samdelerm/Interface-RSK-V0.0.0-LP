#NEW PROGRAMME DE UWU FOR THE ROBOCUP WORLD
'''
IMPLANTATION DES LIBRAIRIES UwU
'''
import rsk 
from time import sleep
import math


#######################################################################################################################################

'''
INITIALISATION DES VARIABLES UwU
'''

#position de la balle 
xb = 0
yb = 0

#position des robot allies
rx1 = 0 # robot 1 ( attaquant )
ry1 = 0
ra1 = 0

rx2 = 0 # robot 2 ( défenseur )
ry2 = 0
ra2 = 0

#position des robot enemie
erx1 = 0 # robot 1 ( attaquant )
ery1 = 0
era1 = 0

erx2 = 0 # robot 2 ( défenseur )
ery2 = 0
era2 = 0

#Pénalité
pr1 = 0  #alliée
pr2 = 0
per1 = 0 #enemie
per2 = 0

#Zones par raport au centre et à la balle
zonet = 0
zoneb = 0

#Sélection des numéros des baka (Numéros de Robot)
nr = 1 
nr2 = 2

#creation d'une variable de teste
test = 0

#variable d'angle de coté en fonction de quel cote on défend / attaque
ag = 0

#⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣶⣶⣤⣤⣤⣤⣶⣶⣶⣶⣶⣶⣦⣤⣤⡀⢀⠀⣶⠀         UU    UU   ww              ww  UU     UU
#⢸⣿⣿⣿⣿⣿⣿⡿⢿⣿⡿⠟⢻⣿⣿⡟⠛⠛⠛⠉⠙⠛⠋⠀⠈⠉⠈⠉⠁         UU    UU    ww            ww   UU     UU
#⢸⣿⠿⠟⠋⠉⠀⢀⣾⡿⠉⠀⠈⠸⣿⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀           UU    UU      ww   ww    ww     UU    UU
#   ⠀⠀⠀⠀⠀⠀⠉⠁⠀⠀⠀⠀  ⠹⣿⣷⣤⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀         UU    UU       ww ww ww ww      UU    UU
#    ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀            UU UU          ww    ww         UU UU
####################################################################################################################################### – ╾━╤デ╦︻  
'''ICI'''#SELECTION EQUIPE + COTEE   ################################################################################################## – ╾━╤デ╦︻
team = 'blue' #                                                                                                                        – ╾━╤デ╦︻
cotee = "+" #ecrire + si on défend du cote positif, + signifie attaque en négatif                                                       – ╾━╤デ╦︻
#                                                                                                                                       – ╾━╤デ╦︻
####################################################################################################################################### – ╾━╤デ╦︻
####################################################################################################################################### – ╾━╤デ╦︻

#variable balle devant 
balledevant = 0

Tert = 0

Ypositionbut = 0.1
Xobjectif = 0.1
Xpositionbut = 0.94
Yobjectif = 0.1


if team == 'blue' : 
    teame = 'green'
else :
    teame = 'blue'
print('Equipe choisie : ', team)
print('Equipe ennemie : ', teame)
print('Défense en x :', cotee)



#Orientation des baka en fonction du coté
if cotee == "+":  
    ag = 0
    pn = 1
elif cotee == "-":
    ag = math.pi
    pn = -1
else:
    print('erreur cotee')

#variable calcule d'angle
angle  =  0
angle2 = 0

#mise en place de la variable de prédiction de trajectoire
prediction = 0
prediction2 = 0
prediction_final = 0

#calcule des distance entre les baka et la balle
dbra = 0 #alliée
dbre = 0 #enemie

##############################################################################################################################################################################################################################################################################  
############################################################################################################################################################################################################################################################################## 


'''
CONNEXION AU SERVEUR
'''
with rsk.Client(host='127.0.0.1', key='', wait_ready=False) as client: #127.0.0.1  192.168.0.100 #192.0.0.100


    while True :




        '''
        MISE EN PLACE DES VARIABLES DE POSITION
        '''
        
        #recup info position balle
        if client.ball is None:
            print('balle non détectée',client.ball)
            print('Pas Balle')
        else:
            xb=client.ball[0]
            yb=client.ball[1]
            

        #recup info position baka
        if client.robots[team][nr].position is None:
            print('no detect',client.robots[team][nr].position)
            print('Pas robot attaquant')
        else:
            rx1=client.robots[team][nr].position[0]
            ry1=client.robots[team][nr].position[1]
            ra1=client.robots[team][nr].pose[2]
        
        #recup info position baka
        if client.robots[team][nr2].position is None:
            print('no detect',client.robots[team][nr2].position)
            print('Pas robot defence')
        else:
            rx2=client.robots[team][nr2].position[0]
            ry2=client.robots[team][nr2].position[1]
            ra2=client.robots[team][nr2].pose[2]
        
        #recup info position baka enemie
        if client.robots[teame][nr].position is None:
            print('no detect',client.robots[teame][nr].position)
            print('Pas robot attaquantadverse')
        else:
            erx1=client.robots[teame][nr].position[0]
            ery1=client.robots[teame][nr].position[1]
            era1=client.robots[teame][nr].pose[2]
            

        #recup la position du baka enemie 2
        if client.robots[teame][nr2].position is None:
            print('no detect',client.robots[teame][nr2].position)
            print('Pas robot attaquant adverse2')
        else:
            erx2=client.robots[teame][nr2].position[0]
            ery2=client.robots[teame][nr2].position[1]
            era2=client.robots[teame][nr2].pose[2]
        
        if client.referee and "teams" in client.referee and team in client.referee["teams"] and "robots" in client.referee["teams"][team] and nr in client.referee["teams"][team]["robots"] and client.referee["teams"][team]["robots"][nr] is not None and "penalized" in client.referee["teams"][team]["robots"][nr]:
            pr1 = client.referee["teams"][team]["robots"][nr]["penalized"]
        else:
         print('referee no detected a1')

        
        if client.referee and "teams" in client.referee and team in client.referee["teams"] and "robots" in client.referee["teams"][team] and nr2 in client.referee["teams"][team]["robots"] and client.referee["teams"][team]["robots"][nr] is not None and "penalized" in client.referee["teams"][team]["robots"][nr2]:
            pr2 = client.referee["teams"][team]["robots"][nr2]["penalized"]
        else:
            print('referee no detected a2')


        if client.referee and "teams" in client.referee and teame in client.referee["teams"] and "robots" in client.referee["teams"][teame] and nr in client.referee["teams"][teame]["robots"] and client.referee["teams"][teame]["robots"][nr] is not None and "penalized" in client.referee["teams"][teame]["robots"][nr]:
            per1 = client.referee["teams"][teame]["robots"][nr]["pesnalized"]
        else:
         print('referee no detected e1')


        if client.referee and "teams" in client.referee and teame in client.referee["teams"] and "robots" in client.referee["teams"][teame] and nr2 in client.referee["teams"][teame]["robots"] and client.referee["teams"][teame]["robots"][nr] is not None and "penalized" in client.referee["teams"][teame]["robots"][nr2]:
            per2 = client.referee["teams"][teame]["robots"][nr2]["penalized"]
        else:
            print('referee no detected e2')


        def verifballedevant(): # verif si balle devans
            balledevant = pn*(xb-rx1)
            if balledevant>rx1: #balledevant
                Tert=1
            if balledevant<rx1: #ballederriere
                Tert=0
            return(Tert)
        
        def positionforbut():
            if ery2>0:
                Ypositionbut= ery2-0.14
            else:
                Ypositionbut = ery2 +0.14
            return (Ypositionbut)
        
        def vise2000():
            A = (yb - Ypositionbut )/(xb - Xpositionbut )
            B = yb - A*xb
            if cotee== 0 :
                
                Xobjectif = xb - 0.11
                if pn*xb > 0 :
                    Yobjectif = A*(xb+0.08)+B
                    print ('ici')
                else:
                    Yobjectif = A*(xb- 0.016)+B
            else:
                Xobjectif = xb+ 0.11
                if pn*xb > 0 :
                    Yobjectif = A*(xb-0.08)+B
                    print ('ici2')
                else:
                    Yobjectif = A*(xb+ 0.016)+B
            
            print("equation de droite",A,"x + ",B)   
            print(Xobjectif , Yobjectif)
            return(Xobjectif , Yobjectif,A,B)
        '''# recup des pénalités présentes robot alliée 1
        if client.referee["teams"][team]["robots"][nr]["penalized"] is None:
            print('referee no dectcted', client.referee["teams"][team]["robots"][nr]["penalized"] )
        else:
            pr1 = client.referee["teams"][team]["robots"][nr]["penalized"]

        # recup des pénalités présentes robot alliée 2
        if client.referee["teams"][team]["robots"][nr2]["penalized"] is None:
            print('referee no dectcted', client.referee["teams"][team]["robots"][nr2]["penalized"] )
        else:
            pr2 = client.referee["teams"][team]["robots"][nr2]["penalized"]


        # recup des pénalités présentes robot enemie 1
        if client.referee["teams"][teame]["robots"][nr]["penalized"] is None:
            print('referee no dectcted', client.referee["teams"][teame]["robots"][nr]["penalized"] )
        else:
            per1 = client.referee["teams"][teame]["robots"][nr]["penalized"]

        # recup des pénalités présentes robot enemie 2
        if client.referee["teams"][teame]["robots"][nr2]["penalized"] is None:
            print('referee no dectcted', client.referee["teams"][teame]["robots"][nr2]["penalized"] )
        else:
            per2 = client.referee["teams"][teame]["robots"][nr2]["penalized"]'''
            
            
        
        # mise en place de la zone dans laquelle se trouve le baka par rapport au TERRAIN 
        if rx1 > 0 :
            if ry1 > 0 :
                zonet = 'a'
            elif ry1 < 0 :
                zonet = 'b'
            else :
                zonet = 'ab'
        elif rx1 < 0 :
            if ry1 > 0 : 
                zonet = 'd'
            elif ry1 < 0 :
                zonet = 'c'
            else : 
                zonet = 'cd'
        else :
            zonet = 'centre'


        # mise en place de la zone dans laquelle se trouve le baka par rapport à la BALLE
        if rx1 > xb :
            if ry1 > yb :
                zoneb = 'a'
            elif ry1 < yb :
                zoneb = 'b'
            else :
                zoneb = 'ab'
        elif rx1 < xb :
            if ry1 > yb : 
                zoneb = 'd'
            elif ry1 < yb :
                zoneb = 'c'
            else : 
                zoneb = 'cd'
        else :
            zoneb = 'centre'

        #calcul de l'angle
        if cotee == '+' :
            angle = - math.atan(ry1/(0.915-rx1)) + ag
        elif cotee == '-' :
            angle = math.atan(ry1/(0.915-rx1)) + ag

        if cotee == '+' :
            angle2 = - math.atan(ry2/(0.915-rx2)) + ag
        elif cotee == '-' :
            angle2 = math.atan(ry2/(0.915-rx2)) + ag

        if ag+0.05>angle>ag-0.05:
            angle = angle
        elif 3.14 > angle > 0 : 
            angle = angle - 0.1
        elif 6.28 > angle > 3.14 : 
            angle = angle + 0.1

        if ag+0.05>angle2>ag-0.05:
            angle2 = angle2
        elif 3.14 > angle > 0 : 
            angle2 = angle2 - 0.1
        elif 6.28 > angle2 > 3.14 : 
            angle2 = angle2 + 0.1
        

        #calcule les distance entre les baka et la balle
        dbra = math.sqrt(((rx1-xb)**2)+((ry1-yb)**2)) #Distance Robot1-balle  UwU
        dbra2 = math.sqrt(((rx2-xb)**2)+((ry2-yb)**2)) #Distance Robot2-balle  UwU
        dbre = math.sqrt(((erx1-xb)**2)+((ery1-yb)**2)) #Attaquant ennemi 1 UwU
        dbre2 = math.sqrt(((erx2-xb)**2)+((ery2-yb)**2)) #Attaquant ennemi 2 UwU

        #calcul de la postion pour la trajectoire
        if cotee == '-':
            if dbre < dbre2:        
                prediction = ery1 + (0.915-erx1)/ math.tan((math.pi/2)-era1) 
                

                if ery1+0.05> prediction > ery1-0.05:
                    prediction = prediction
                elif prediction > ery1 :
                    prediction = prediction -0.1
                elif prediction < ery1 :
                    prediction = prediction + 0.1
            elif dbre > dbre2 :

                prediction = ery2 + (0.915-erx2)/ math.tan((math.pi/2)-era2)

                if ery2+0.05> prediction2 > ery2-0.05:
                    prediction2 = prediction2
                elif prediction2 > ery2 :
                    prediction2 = prediction2 -0.1
                elif prediction2 < ery2 :
                    prediction2 = prediction2 + 0.1

        elif cotee =='+':

            if dbre < dbre2:  
                #prediction = (0.61-abs(ery1))+((math.tan(abs(math.pi-era1)))*(0.915-abs(erx1)))  - 0.5
                prediction = (math.tan(math.pi - era1 ) * (0.915-erx1)) + ery1
                

                if ery1+0.05> prediction > ery1-0.05:
                    prediction = prediction
                elif prediction > ery1 :
                    prediction = prediction - 0.1
                elif prediction < ery1 :
                    prediction = prediction + 0.1
            elif dbre > dbre2:

                #prediction = (0.61-abs(ery2))+((math.tan(abs(math.pi-era2)))*(0.915-abs(erx2)))  - 0.5
                prediction = (math.tan(math.pi - era2 ) * (0.915-erx2)) + ery2

                if ery2+0.05> prediction2 > ery2-0.05:
                    prediction2 = prediction2
                elif prediction2 > ery2 :
                    prediction2 = prediction2 -0.1
                elif prediction2 < ery2 :
                    prediction2 = prediction2 + 0.1
        

        
        
            

        

        '''balledevant = pn*(xb-rx1+pn*0.1) # verif posi devant / arr  etat : ... si balle devant si balle derriere etat : ...'''
        

        ####################################################################################################################################### 
        ####################################################################################################################################### 
     

        '''
        Ataka (Nom missile antichar guidé), Partie attaque du programme
        '''
        try :

            def attaquant():
                #si balle devant
                if Tert==1:
                    if yb*pn>0: #gauche
                        client.robots[team][nr].goto((Xobjectif, Yobjectif, angle), wait=False)
                    if yb*pn<0: #droit
                        client.robots[team][nr].goto((Xobjectif, Yobjectif, angle), wait=False)
                    #client.robots[team][nr].goto((xb+pn*(+0.05), yb, ag), wait=False)
                    print('va vers balle')
                if Tert==0:
                    client.robots[team][nr].goto((xb+pn*(-0.05), yb, angle), wait=False)
                    print('va vers derriere balle')

                #si balle prés du robot --> kick
                
                if (xb-rx1>0.15) :
                    client.robots[team][nr].kick()
                    print('robot a kick')
                    sleep(1)
            
            positionforbut()
            vise2000()
            attaquant()

        except rsk.client.ClientError as e:
            print(e)

        

            
            
            '''PROGRAMME GOAL DU TURFU !!!!'''



        try:
            if cotee =='+'  :
                if pr1 == True and per1 == True   :
                    client.robots[team][nr2].goto((xb , yb, angle2), wait=False)
                elif dbre < dbra and  rx1 > xb :
                    client.robots[team][nr2].goto((xb , yb, angle2), wait=False)
                elif -0.29 < prediction < 0.29 :
                    client.robots[team][nr2].goto((-0.80*pn , prediction, angle2), wait=False)
                elif prediction > 0:
                    client.robots[team][nr2].goto((-0.80*pn , 0.29, angle2), wait=False)
                elif prediction < 0:
                    client.robots[team][nr2].goto((-0.80*pn , -0.29, angle2), wait=False)
            elif cotee =='-':
                if pr1 == True and per1 == True  :
                    client.robots[team][nr2].goto((xb , yb, angle2), wait=False)
                elif dbre < dbra and  rx1 < xb :
                    client.robots[team][nr2].goto((xb , yb, angle2), wait=False)
                elif -0.29 < prediction < 0.29 :
                    client.robots[team][nr2].goto((-0.80*pn , prediction, angle2), wait=False)
                elif prediction > 0:
                    client.robots[team][nr2].goto((-0.80*pn , 0.29, angle2), wait=False)
                elif prediction < 0:
                    client.robots[team][nr2].goto((-0.80*pn , -0.29, angle2), wait=False)
                    
            





        except rsk.client.ClientError as e:
            print(e)