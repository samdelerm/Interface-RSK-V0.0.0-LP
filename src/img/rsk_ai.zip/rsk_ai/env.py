ip = '192.168.100.248'
key = ''
couleur = 'green'
atta = 1
defen = 0

DISTANCE_TO_SWITCH = 0.2
INTERVALLE_SWITCH = 3 # seconds

if(atta == 1):
    defen = 2
else:
    defen = 1
theirColor = ''
if couleur == 'blue':
    theirColor = 'green'
else:
    theirColor = 'blue'
class environnement:
    def __init__(self,api):
        
        self.api = api

        self.positive = api.getPositive(couleur)
        self.sign = -1 if self.positive else 1

        

        

        
    
    
    

