import rsk
import env 
from api import *
from env import *
from attaquant import attaquant
from defenseur import defenseur
from calc import *
import time 



with rsk.Client(host=env.ip, key=env.key) as client:
    api = api(client)
    Ienv = environnement(api)
    attaquant = attaquant(Ienv)
    defenseur = defenseur(Ienv)
    Icalc = calc(Ienv)
    last_switch = time.time()
    while True : 
        api.update_poses()
        attaquant.run()
        defenseur.run()



        penalized = api.Penalised()
        MyStatus = penalized[env.couleur][attaquant.robot['number']] and penalized[env.couleur][defenseur.robot['number']]
        if penalized[env.couleur][attaquant.robot['number']] and penalized[env.theirColor][Icalc.enemiesAttaq()]:
            if(time.time() - last_switch > env.INTERVALLE_SWITCH/2):
                attaquant.switch()
                defenseur.switch()
                last_switch = time.time()
        if (not(MyStatus) and calc.distance(api.poses[env.couleur][defenseur.robot['number']] , api.poses['ball']) < calc.distance(api.poses[env.couleur][attaquant.robot['number']] , api.poses['ball']) + env.DISTANCE_TO_SWITCH ):
            if(time.time() - last_switch > env.INTERVALLE_SWITCH):
                attaquant.switch()
                defenseur.switch()
                last_switch = time.time() 



