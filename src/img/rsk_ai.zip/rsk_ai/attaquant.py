import env 
import time 
from api import *
from env import *
from rsk import constants
from calc import *


class attaquant:

    def __init__(self, envi, num = env.atta):
        self.api = envi.api  
        self.env = envi
        self.robot = {'color':env.couleur , 'number':num}
        self.kickTime = 0
        self.timeAB = 0
        self.calc = calc(envi)

    def switch(self):
        num = 1 if self.robot['number'] == 2 else 2
        self.robot = {'color':self.robot['color'],'number':num}
        

    def kick(self):
        if(time.time() - self.kickTime > 2):
            self.kickTime = time.time()
            while(time.time() - self.kickTime < 0.1):
                self.api.control(self.robot, constants.max_linear_acceleration)
            self.api.kick(self.robot)
            self.api.control(self.robot, 0.0)
            self.kickTime = time.time()
            return True
        else :
            return False

    def follow(self):
        
        mypos = self.api.poses[self.robot['color']][self.robot['number']]
        ballpos = self.api.poses['ball']
        
        
        dist = constants.robot_radius+constants.ball_radius + INNACURACY_AROUND
        if(ballpos[0]*self.env.sign  < mypos[0]*self.env.sign):
            if(mypos[1]>ballpos[1]):
                pos = (ballpos[0]-dist*self.env.sign,ballpos[1]+dist)
            else :
                pos = (ballpos[0]-dist*self.env.sign,ballpos[1]-dist)
        elif(ballpos[0]*self.env.sign-INNACURACY_DISTANCE  < mypos[0]*self.env.sign < ballpos[0]*self.env.sign+INNACURACY_DISTANCE):
            pos = (mypos[0]-dist*self.env.sign, mypos[1])
        else:
            pos = self.calc.whereToGo(self.robot)
        tetha = calc.look_at(pos,self.calc.whereToKick(self.robot))
        self.api.goto(self.robot, pos[0],pos[1],tetha)
        
    
    
    
    def goBack(self):
        pos = self.calc.whereToGo(self.robot,0.20)
        tetha = calc.look_at(pos,self.calc.whereToKick(self.robot))
        self.api.goto(self.robot, pos[0],pos[1],tetha)

    def UpdateTimeAB(self):
        ball_around = self.calc.ballAroundRobot(self.robot , 0.10)
        
        if(ball_around and self.timeAB == 0):
            self.timeAB = time.time()
        elif(not(ball_around) and self.timeAB != 0):
            self.timeAB = 0

    def ContestBall(self):
        distance = constants.robot_radius + constants.ball_radius + INNACURACY_AROUND
        if(calc.distance(self.api.poses[env.theirColor][self.calc.enemiesAttaq()], self.api.poses['ball']) <= distance):
            self.api.goto(self.robot, self.api.poses['ball'][0], self.api.poses['ball'][1], calc.look_at(self.api.poses[self.robot['color']][self.robot['number']], self.api.poses['ball']))
            return False
        return True
    
    def run(self):
        
        canGoal = self.calc.canGoal(self.robot)
        self.UpdateTimeAB()   
        if(canGoal):
            if(not(self.kick())): 
                self.follow()
        else:
            if(self.timeAB != 0 and time.time() - self.timeAB >=  2):
                self.goBack()   
            else:
                if(self.ContestBall()):
                    self.follow()
    
